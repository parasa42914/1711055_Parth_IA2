export interface course {

    name:string;
    description:string;
    skill:string;
    prereq:string;
    date:string;
    feedback:string;
    ratting:string;
  }
  